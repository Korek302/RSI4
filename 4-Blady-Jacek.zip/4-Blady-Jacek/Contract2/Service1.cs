﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

/// <summary>
/// WcfServiceContract - Contract2 namespace
/// Jacek Blady 228140
/// </summary>
namespace Contract2
{
    /// <summary>
    /// Service Contract Interface IStrumien Implementation as MojStrumien
    /// </summary>
    public class MojStrumien : IStrumien
    {
        /// <summary>
        /// Implementation of download method from IStrumien interface
        /// Returns data requested by client via streaming
        /// </summary>
        /// <param name="request"> Specifies the client request - RequestFileMessage</param>
        /// <returns> Object with requested data and informations about it - ResponseFileMessage</returns>
        public ResponseFileMessage download(RequestFileMessage request)
        {
            ResponseFileMessage wynik = new ResponseFileMessage();
            string nazwa = request.nazwa1;
            FileStream myFile;
            Console.WriteLine("-->Wywolano getStream");
            string filePath = Path.Combine(System.Environment.
            CurrentDirectory, nazwa);
            // wyjatek na wypadek bledu otwarcia pliku
            try
            {
                myFile = File.OpenRead(filePath);
            }
            catch (IOException ex)
            {
                Console.WriteLine(String.Format("Wyjatek otwarcia pliku {0} :",
                filePath));
                Console.WriteLine(ex.ToString());
                throw ex;
            }
            wynik.nazwa2 = nazwa;
            wynik.rozmiar = myFile.Length;
            wynik.dane = myFile;
            return wynik;
        }

        /// <summary>
        /// Implementation of listfiles method form IStrumien interface
        /// Public method used for getting list of all filed avaliable on server
        /// </summary>
        /// <returns> array of file names - string[]</returns>
        public string[] listfiles()
        {
            string[] files = Directory.GetFiles(Environment.CurrentDirectory);
            return files;
        }

        /// <summary>
        /// Implementation of upload method from IStrumien interface
        /// Recives data via streaming from client response object and save it on the server
        /// </summary>
        /// <param name="request"> Object given by client to be saved on server - ResponseFileMessage</param>
        public void upload(ResponseFileMessage request)
        {
            const int bufferLength = 8192; //długość bufora 8KB
            int bytecount = 0; //licznik
            int counter = 0; //licznik pomocniczy
            byte[] buffer = new byte[bufferLength];
            string filePath = Path.Combine(System.Environment.
            CurrentDirectory, request.nazwa2);
            Stream instream = request.dane;

            Console.WriteLine("--> Zapisuje plik {0}", filePath);
            FileStream outstream = File.Open(filePath, FileMode.Create,
            FileAccess.Write);
            //zapisywanie danych porcjami
            while ((counter = instream.Read(buffer, 0, bufferLength)) > 0)
            {
                outstream.Write(buffer, 0, counter);
                Console.Write(".{0}", counter); //wypisywanie info. po każdej części
                bytecount += counter;
            }
            Console.WriteLine();
            Console.WriteLine("Zapisano {0} bajtow", bytecount);
            outstream.Close();
            instream.Close();
            Console.WriteLine();
            Console.WriteLine("--> Plik {0} zapisany", filePath);
        }
    }
}
