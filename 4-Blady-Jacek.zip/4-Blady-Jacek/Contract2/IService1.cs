﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

/// <summary>
/// Wcf Service Contract - Contract2 namespace
/// Jacek Blady 228140
/// </summary>
namespace Contract2
{
    /// <summary>
    /// Service Contract Interface IStrumien
    /// </summary>
    [ServiceContract]
    public interface IStrumien
    {
        /// <summary>
        /// Returns data requested by client via streaming
        /// </summary>
        /// <param name="request"> Specifies the client request - RequestFileMessage</param>
        /// <returns> Object with requested data and informations about it - ResponseFileMessage</returns>
        [OperationContract]
        ResponseFileMessage download(RequestFileMessage request);

        /// <summary>
        /// Recives data via streaming from client response object and save it on the server
        /// </summary>
        /// <param name="request"> Object given by client to be saved on server - ResponseFileMessage</param>
        [OperationContract]
        void upload(ResponseFileMessage request);

        /// <summary>
        /// Public method used for getting list of all filed avaliable on server
        /// </summary>
        /// <returns> array of file names - string[]</returns>
        [OperationContract]
        string[] listfiles();
    }

    /// <summary>
    /// Public class used by client to request data from server
    /// </summary>
    [MessageContract]
    public class RequestFileMessage
    {
        /// <summary>
        /// Name of the requested resource - string
        /// </summary>
        [MessageBodyMember]
        public string nazwa1;
    }

    /// <summary>
    /// Public class used to pass data and informations about it from server
    /// </summary>
    [MessageContract]
    public class ResponseFileMessage
    {
        /// <summary>
        /// Name of the resource - string
        /// </summary>
        [MessageHeader]
        public string nazwa2;

        /// <summary>
        /// Size of the resource - long
        /// </summary>
        [MessageHeader]
        public long rozmiar;

        /// <summary>
        /// Passed data - Stream
        /// </summary>
        [MessageBodyMember]
        public Stream dane;
    }
}
