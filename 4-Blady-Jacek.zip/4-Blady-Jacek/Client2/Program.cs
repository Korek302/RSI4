﻿using Client2.ServiceReference1;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Wcf Service Client - Client2 namespace
/// Jacek Blady 228140
/// </summary>
namespace Client2
{
    /// <summary>
    /// Main Program class with entry point
    /// </summary>
    class Program
    {
        /// <summary>
        /// Program Entry point
        /// </summary>
        /// <param name="args"> command line args </param>
        static void Main(string[] args)
        {
            StrumienClient client2 = new StrumienClient("BasicHttpBinding_IStrumien");
            string filePath = Path.Combine(System.Environment.CurrentDirectory, "klient.jpg");

            bool end = false;
            while (!end)
            {
                try
                {
                    int cmd = -1;

                    Console.WriteLine("1 - upload(string nazwapliku)");
                    Console.WriteLine("2 - download(string nazwapliku)");
                    Console.WriteLine("3 - Wypisz pliki z serwera");
                    Console.WriteLine("4 - Wypisz pliki lokalne");
                    Console.WriteLine("5 - Koniec");

                    do
                    {
                        Console.Write("Podaj komende: ");
                        string s = Console.ReadLine();
                        bool success = int.TryParse(s, out cmd);
                        if (!success)
                        {
                            cmd = -1;
                        }
                    } while (cmd < 1 || cmd > 5);

                    if (cmd == 1)
                    {
                        Console.Write("Podaj nazwe pliku lokalnego:");
                        Stream s = null;
                        long roz;
                        string n = Console.ReadLine();
                        OpenFile(n, out roz, out s);
                        client2.upload(n, roz, s);
                    }
                    else if (cmd == 2)
                    {
                        Console.Write("Podaj nazwe pliku na serwerze:");
                        Stream fs = null;
                        long rozmiar;
                        string nnn = Console.ReadLine();
                        nnn = client2.download(nnn, out rozmiar, out fs);
                        filePath = Path.Combine(System.Environment.CurrentDirectory, nnn);
                        ZapiszPlik(fs, filePath);
                    }
                    else if (cmd == 3)
                    {
                        string[] files = client2.listfiles();
                        foreach (var file in files)
                            Console.WriteLine(file);
                    }
                    else if (cmd == 4)
                    {
                        string[] files = Directory.GetFiles(Environment.CurrentDirectory);
                        foreach (var file in files)
                            Console.WriteLine(file);
                    }
                    else if (cmd == 5)
                    {
                        end = true;
                    }
                }
                catch
                {
                    Console.WriteLine("Error");
                }
            }
            
            client2.Close();
            Console.WriteLine();
            Console.WriteLine("Nacisnij <ENTER> aby zakonczyc.");
            Console.ReadLine();
        }
        
        static void OpenFile(string name, out long roz, out Stream data)
        {
            FileStream myFile;
            Console.WriteLine("-->Wywolano getStream");
            string filePath = Path.Combine(System.Environment.
            CurrentDirectory, name);
            try
            {
                myFile = File.OpenRead(filePath);
            }
            catch (IOException ex)
            {
                Console.WriteLine(String.Format("Wyjatek otwarcia pliku {0} :",
                filePath));
                Console.WriteLine(ex.ToString());
                throw ex;
            }
            data = myFile;
            roz = myFile.Length;
        }
        static void ZapiszPlik(System.IO.Stream instream, string filePath)
        {
            const int bufferLength = 8192; //długość bufora 8KB
            int bytecount = 0; //licznik
            int counter = 0; //licznik pomocniczy
            byte[] buffer = new byte[bufferLength];

            Console.WriteLine("--> Zapisuje plik {0}", filePath);
            FileStream outstream = File.Open(filePath, FileMode.Create,
            FileAccess.Write);
            //zapisywanie danych porcjami
            while ((counter = instream.Read(buffer, 0, bufferLength)) > 0)
            {
                outstream.Write(buffer, 0, counter);
                Console.Write(".{0}", counter); //wypisywanie info. po każdej części
                bytecount += counter;
            }
            Console.WriteLine();
            Console.WriteLine("Zapisano {0} bajtow", bytecount);
            outstream.Close();
            instream.Close();
            Console.WriteLine();
            Console.WriteLine("--> Plik {0} zapisany", filePath);
        }
    }
}
